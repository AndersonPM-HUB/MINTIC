/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author Dell
 */
public class MascotasporEspecie {
    private String especie;
    private int cantidadMascotasporEspecie;

    /**
     * @return the especie
     */
    public String getEspecie() {
        return especie;
    }

    /**
     * @param especie the especie to set
     */
    public void setEspecie(String especie) {
        this.especie = especie;
    }

    /**
     * @return the cantidadMascotasporEspecie
     */
    public int getCantidadMascotasporEspecie() {
        return cantidadMascotasporEspecie;
    }

    /**
     * @param cantidadMascotasporEspecie the cantidadMascotasporEspecie to set
     */
    public void setCantidadMascotasporEspecie(int cantidadMascotasporEspecie) {
        this.cantidadMascotasporEspecie = cantidadMascotasporEspecie;
    }
    
}
